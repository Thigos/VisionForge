# vf, AGPL-3.0 license

__version__ = "1.0.0"

from vf.VisionForge import VisionForge
